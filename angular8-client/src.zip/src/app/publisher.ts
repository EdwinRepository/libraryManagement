export class Publisher {
    publisherId: number;
    name: string;
    address: string;
    
  }
  