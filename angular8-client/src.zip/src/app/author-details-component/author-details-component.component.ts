import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from "rxjs";
import { AuthorService } from "../author.service";
import { Author } from "../author";
@Component({
  selector: 'app-author-details-component',
  templateUrl: './author-details-component.component.html',
  styleUrls: ['./author-details-component.component.css']
})
export class AuthorDetailsComponentComponent implements OnInit {

  authors: Observable<Author[]>;

  constructor(private authorService: AuthorService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
    console.log("Init called");
  }
  reloadData() {
    console.log("author service called");
    this.authors = this.authorService.getAuthorList();
    console.log(this.authors);
  }

}
