import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from "rxjs";
import { UserService } from "../user.service";
import { User } from "../user";
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user: User = new User();
  newUser(): void {
    
    this.user = new User();
  }
  
  constructor(private userService: UserService,
    private router: Router) { }

  ngOnInit() {
  }
  onSubmit() {    
    this.save();      
  }
  save() {
    console.log('save called', this.user);
    this.userService.addUser(this.user).subscribe(data => {console.log(data)
      if(data !=null) {
        this.user = new User();
        console.log("save method called");
        this.gotoList();
        }
    }, error => console.log(error));

    this.user = new User();

  }
  gotoList() {        
    this.router.navigate(['/user']);
}
}
