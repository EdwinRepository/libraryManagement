export class User {
    userId: number;
    userName: string;
    address: string;
    userType: string;
    
  }
  