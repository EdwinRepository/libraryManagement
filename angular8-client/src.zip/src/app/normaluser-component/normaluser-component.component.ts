import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-normaluser-component',
  templateUrl: './normaluser-component.component.html',
  styleUrls: ['./normaluser-component.component.css']
})
export class NormaluserComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
