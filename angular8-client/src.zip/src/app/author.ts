export class Author {
    authorId: number;
    name: string;
    
  }
  