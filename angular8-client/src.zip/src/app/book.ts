export class Book {
    bookId: number;
    bookPrice: string;
    title: string;
    authorName: string;
   
  }
  